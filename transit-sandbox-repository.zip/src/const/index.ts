export const Shape2Mode = {
  1: 'diamond',
  2: 'square',
  3: 'circle',
};

export const Test = {
};
