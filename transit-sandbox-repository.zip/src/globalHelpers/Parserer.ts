class Parserer {
  public options: {
    api: {
      appId: string;
      restKey: string;
    };
  };

  constructor() {
    this.options = {
      api: {
        appId: 'uuwsTR5a4MgUAANoM7x87qw2GKcIvudpiPEwOjP2',
        restKey: 'JlOWL10VSAvGZxNhgLUzqxqw3Lxl8vqKB7v3SD0Q',
      },
    };
  }
}

export default Parserer;
